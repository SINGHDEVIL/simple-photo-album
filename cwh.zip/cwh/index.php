<?php
// Sample data
$images = glob('images/*.{jpg,jpeg,png,gif}', GLOB_BRACE); // Fetch images from the directory
$total_pages = ceil(count($images) / 3); 
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1; 


if ($current_page < 1) {
    $current_page = 1;
} elseif ($current_page > $total_pages) {
    $current_page = $total_pages;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flipbook Photo Album</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
</head>
<body>
    <div class="book">
        <input type="radio" name="page" id="c1" <?php echo ($current_page == 1) ? 'checked' : ''; ?>>
        <input type="radio" name="page" id="c2" <?php echo ($current_page == 2) ? 'checked' : ''; ?>>
        <input type="radio" name="page" id="c3" <?php echo ($current_page == 3) ? 'checked' : ''; ?>>

        <div class="flip-book">
            <?php
            // Loop to create pages
            for ($i = 1; $i <= $total_pages; $i++) {
                echo '<div class="flip" id="p' . $i . '">';
                echo '<div class="front">';
                // Display images for the current page
                for ($j = ($i - 1) * 3; $j < $i * 3 && $j < count($images); $j++) {
                    if ($j == ($i - 1) * 3) { // Main image
                        echo '<img src="' . $images[$j] . '" class="main-image">';
                    } else { // Smaller images
                        echo '<img src="' . $images[$j] . '" class="small-image">';
                    }
                }
                echo '</div>';
                echo '<div class="back">';
                echo '<h2>Page ' . $i . '</h2>';
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>

        <div class="next-btn" onclick="nextPage()">Next</div>
        <div class="back-btn" onclick="prevPage()">Previous</div>
    </div>
</body>
</html>












