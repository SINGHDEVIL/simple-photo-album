// Get current page from PHP
let currentPage = <?php echo $current_page; ?>;
const totalPages = <?php echo $total_pages; ?>;

// Function to go to the next page
function nextPage() {
    if (currentPage < totalPages) {
        document.getElementById('c' + currentPage).checked = false; // Uncheck current
        currentPage++;
        document.getElementById('c' + currentPage).checked = true; // Check next
    }
}

// Function to go to the previous page
function prevPage() {
    if (currentPage > 1) {
        document.getElementById('c' + currentPage).checked = false; // Uncheck current
        currentPage--;
        document.getElementById('c' + currentPage).checked = true; // Check previous
    }
}




